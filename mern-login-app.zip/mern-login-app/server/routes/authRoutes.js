const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
// const User = require('../models/User');
// const router  = express.Router();
// const login = require('../controllers/auth-controller')
// import login from '../controllers/auth-controller.js';
// const router = express.Router();
const express = require('express');
const login = require('../controllers/auth-controller'); // 👈 No need for .js

const router = express.Router();

router.post('/login', login);

module.exports = router;

// // Register
// router.post('/register', async (req, res) => {
//   const { name, email, password } = req.body;
//   const userExist = await User.findOne({ email });
//   if (userExist) return res.status(400).json({ message: 'User already exists' });

//   const hash = await bcrypt.hash(password, 10);
//   const user = new User({ name, email, password: hash });
//   await user.save();
//   res.status(201).json({ message: 'User registered successfully' });
// });

// // Login
// router.post('/login', async (req, res) => {
//   const { email, password } = req.body;
//   const user = await User.findOne({ email });
//   if (!user) return res.status(400).json({ message: 'Invalid credentials' });

//   const isMatch = await bcrypt.compare(password, user.password);
//   if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

//   const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
//   res.json({ token, user: { id: user._id, name: user.name, email: user.email } });
// });

router.post('/login', login);
module.exports = router;
