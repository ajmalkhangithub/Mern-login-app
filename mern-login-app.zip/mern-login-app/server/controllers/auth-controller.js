const express =require('express')
const User =require('../models/User')



const login= async (req,res)=>{
    try {
        const { email,password} = req.body;
        const userExist= await User.findOne( { email})

        if(!userExist) return res.status(400).json({ message:"Invalid credentials"})
            const user = await bcrypt.compare(password, userExist.password);
        // if(!user) return res.status(400).json({ message:"Invalid credentials"})
        if(user){
            res.status(200).json({ message:"login successful",
                token: userExist._id.generateToken(),
                userId: userExist._id.toString

            })
        }
        else{
            res.status(400).json({ message:"Invalid credentials"})
        }
    } catch (error) {
        res.status(500).json({ message:"internal server error"})
    }
}

module.exports = { login}